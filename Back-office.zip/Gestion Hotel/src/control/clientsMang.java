package control;

import dao.ClientDao;
import dao.EmployeeDao;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

import dao.ReceptionistDao;
import model.Client;
import model.Employee;
import model.Receptionist;
import model.Receptionist;
public class clientsMang implements Initializable  {

    @FXML
    TextField nameIn;
    @FXML
    TextField emailIn;
    @FXML
    TextField updateEmail;
    @FXML
    TableColumn ID;
    @FXML
    TableColumn NAME;
    @FXML
    TableColumn EMAIL;
    @FXML
    TableView TABLE;

    ClientDao cli = new ClientDao();
    public void find(Event e){
        //resetBtns();
        if(emailIn.getText().equals("")){
            System.out.println("donner l'email a cherche");
            return;
        }

        try{
            Client client = null;
            client = cli.getClientByEmail(emailIn.getText());
            if(client != null){
                nameIn.setText(client.getName());
            }else{
                System.out.println("pas de cette email.");
            }
        }catch (SQLException | ClassNotFoundException err ){
            err.printStackTrace();
        }

    }

    public void add(Event e){
        if (!isRemplir()){
            System.out.println("remplire touts les champes");
            return;
        }
        Client client = new Client();
        client.setEmail(emailIn.getText());
        client.setPassword(emailIn.getText());
        client.setName(nameIn.getText());
        client.setRole("client");
        try{
            int statu = cli.createClient(client);
            if(statu == -2){
                System.out.println("user with email deja existe.");
            }else if(statu == 1){
                System.out.println("donnnne");
                resetBtns();
                refrech();
            }
        }catch(SQLException | ClassNotFoundException err){
            err.printStackTrace();
        }
    }

    public void delete(Event e){
        //resetBtns();
        if(emailIn.getText().equals("")){
            System.out.println("donner l'email a supprimer");
            return;
        }

        try{
            int statu = cli.deleteClient(emailIn.getText());
            if(statu == 1){
                System.out.println("dooonne");
                resetBtns();
                refrech();
            }else if(statu == -2){
                System.out.println("pas de cette email.");
            }
        }catch (SQLException | ClassNotFoundException err ){
            err.printStackTrace();
        }

    }

    public void update(Event e){
        if(updateEmail.getText().equals("")){
            System.out.println("donner l'email a metre a joure");
            return;
        }
        Client client = null;
        try{
            client = cli.getClientByEmail(updateEmail.getText());
            if(client == null){
                System.out.println("pas de cette email.");
            }else{
                client.setEmail(emailIn.getText());
                client.setName(nameIn.getText());
                int statu = cli.updateClient(client);
                if(statu == -2){
                    System.out.println("user with email deja existe.");
                }else if(statu == 1){
                    System.out.println("donnnne");
                    resetBtns();
                    refrech();
                }
            }
        }catch (SQLException | ClassNotFoundException err){
            err.printStackTrace();
        }
    }

    public void resetBtns(){
        nameIn.setText("");
        emailIn.setText("");
    }

    public boolean isRemplir(){
        if(nameIn.getText().equals("") | emailIn.getText().equals("")){
            return false;
        }
        return true;
    }
    public void rtn(Event e){
        Node node = (Node) e.getSource();
        Stage stage = (Stage) node.getScene().getWindow();
        //stage.close();
        try{
            Parent root = FXMLLoader.load(getClass().getResource("/view/AdminPage.fxml"));
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    public void logout(Event e){
        Node node = (Node) e.getSource();
        Stage stage = (Stage) node.getScene().getWindow();
        //stage.close();

        try {
            Parent root = FXMLLoader.load(getClass().getResource("/view/LoginForm.fxml"));
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }


    @Override
    public void initialize(URL location, ResourceBundle resources) {
        refrech();
    }
    public void refrech(){
        ID.setCellValueFactory((new PropertyValueFactory<>("id")));
        NAME.setCellValueFactory((new PropertyValueFactory<>("name")));
        EMAIL.setCellValueFactory((new PropertyValueFactory<>("email")));
        try {
            TABLE.setItems(cli.getAllClientsObservable());
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }
}
