package dao;


public class AdminDao extends ReceptionistDao{
    
    public AdminDao(){
        
    }
}
